<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        /* Define your styles here */
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        .center {
            text-align: center;
        }
        .bold {
            font-weight: bold;
        }
        .sunday {
            background-color: red;
            /* Add any other styles for Sundays here */
        }
        /* Add more styles as needed */
    </style>
</head>
<body>

    <table border="0" cellpadding="0" cellspacing="0" id="sheet0" class="sheet0 gridlines">
        <thead>
            <tr class="row0">
                <th colspan="17" class="style210" style="text-align: center; font-weight: bold; font-size: 30px; height: 100px;">
                    AMBIKA ENTERPRISE (MONTHLY SALARY) <br>
                    @if($companyName) {{ $companyName }} @endif
                </th>
            </tr>
            <tr class="row1">
                <th class="style49" style="border:1px solid black; text-align:center; font-weight: bold;">SR.NO</th>
                <th class="style33" style="width: 140px; border:1px solid black; text-align:center; font-weight: bold;">NAME OF EMPLOYEE</th>
                <th class="style33" style="width: 135px; border:1px solid black; text-align:center; font-weight: bold;">FATHER NAME</th>
                <th class="style33" style="width: 100px; border:1px solid black; text-align:center; font-weight: bold;">DESIGNATION</th>
                <th class="style144" style="width: 100px; border:1px solid black; font-weight: bold; text-align:center;">Rate</th>
                <th class="style144" style="width: 100px; border:1px solid black; font-weight: bold; text-align:center;">Present</th>
                <th class="style144" style="width: 100px; border:1px solid black; font-weight: bold; text-align:center;">OT</th>
                <th class="style144" style="width: 120px; border:1px solid black; font-weight: bold; text-align:center;">Present Amount</th>
                <th class="style144" style="width: 120px; border:1px solid black; font-weight: bold; text-align:center;">OT Amount</th>
                <th class="style144" style="width: 150px; border:1px solid black; font-weight: bold; text-align:center;">Gross Payment</th>
                <th class="style144" style="width: 150px; border:1px solid black; font-weight: bold; text-align:center;">Advance</th>
                <th class="style144" style="width: 150px; border:1px solid black; font-weight: bold; text-align:center;">Remaining Advance</th>
                <th class="style144" style="width: 150px; border:1px solid black; font-weight: bold; text-align:center;">Total Advance</th>
                <th class="style144" style="width: 150px; border:1px solid black; font-weight: bold; text-align:center;">NET Payment</th>
                <th class="style144" style="width: 150px; border:1px solid black; font-weight: bold; text-align:center;">FINAL Payment</th>
                <th class="style144" style="width: 200px; border:1px solid black; font-weight: bold; text-align:center;">A/C NO</th>
                <th class="style144" style="width: 200px; border:1px solid black; font-weight: bold; text-align:center;">IFSC CODE</th>
                <th class="style144" style="width: 250px;border:1px solid black; font-weight: bold; text-align:center;">REMARKS</th>
            </tr>
        </thead>
        <tbody>
            @php $i = 1; @endphp
            @foreach($salaries as $salary)
                @php
                    $income = $salary->getEmployee->income ?? 0;
                    $total_present = $salary->total_present ?? 0;
                    $present_amount = 0;

                    // Check employee income type and calculate present_amount
                    if ($salary->getEmployee->income_type == 0) {
                        // Hourly wage
                        $present_amount = $income * $total_present;
                    } elseif ($salary->getEmployee->income_type == 1) {
                        // Daily wage
                        $days = $salary->getEmployee->days; // Default to 1 to avoid division by zero
                        $present_amount = ($income * $total_present) / $days;
                    }

                    $total_ot = $salary->total_ot ?? 0;
                    $ot_amount = 0;

                    // Check employee income type and calculate ot_amount
                    if ($salary->getEmployee->income_type == 0) {
                        // Hourly wage OT calculation
                        $ot_amount = ($income / 8) * $total_ot * 2;
                        $ot_amount_decimal = number_format($ot_amount, 2, '.', '');
                    } elseif ($salary->getEmployee->income_type == 1) {
                        // Daily wage OT calculation
                        $ot_amount = ((($income / $days)/ 10) * $total_ot);
                        $ot_amount_decimal = number_format($ot_amount, 2, '.', '');
                    }

                    $total_amount = $ot_amount + $present_amount;
                    $total_amount_decimal = number_format($total_amount, 2, '.', '');
                @endphp
                <tr>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $i++ }}</td>
                    <td class="style16" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->first_name ?? '' }} {{ $salary->getEmployee->last_name ?? '' }}</td>
                    <td class="style16" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->father_name ?? '' }} {{ $salary->getEmployee->last_name ?? '' }}</td>
                    <td class="style16" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->getEmployeePost->designation ?? '' }}</td>
                    <td class="style16" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->income ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $total_present ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->total_ot ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $present_amount ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $ot_amount_decimal ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $total_amount_decimal ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->deduct_advance ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->advance ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->total_advance ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->salary ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->salary ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->account_no ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->getEmployee->ifsc_code ?? '' }}</td>
                    <td class="style17" style="border:1px solid black; text-align:center;">{{ $salary->remarks ?? '' }}</td>
                </tr>
            @endforeach

        </tbody>
    </table>

</body>
</html>
